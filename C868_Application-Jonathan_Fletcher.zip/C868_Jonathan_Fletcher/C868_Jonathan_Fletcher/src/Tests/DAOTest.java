package Tests;

import DBUtilities.DBConnection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DAOTest {



    /**
     * This method is to run DB queries prior to launch to ensure proper syntax execution.
     * returns statements if correct, error if not.
     */
    public static void runAppointmentTest(){
        String sql = "SELECT * FROM appointments WHERE Appointment_ID = 1";
        String sql1 = "SELECT * FROM contacts WHERE Contact_ID = 1";
        String sql2 = "SELECT * FROM customers WHERE Customer_ID = 1";
        String sql3 = "SELECT * FROM appointments WHERE User_ID = 1";

        try {
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql);
            PreparedStatement ps1 = DBConnection.getConnection().prepareStatement(sql1);
            PreparedStatement ps2 = DBConnection.getConnection().prepareStatement(sql2);
            PreparedStatement ps3 = DBConnection.getConnection().prepareStatement(sql3);

            ps.execute(sql);
            ps1.execute(sql1);
            ps2.execute(sql2);
            ps3.execute(sql3);

            System.out.println(ps);
            System.out.println(ps1);
            System.out.println(ps2);
            System.out.println(ps3);

            if(sql.equals(null)){
                    System.out.println("Error in Users");
                }
                if(sql1.equals(null)){
                    System.out.println("Error in Contacts");
                }if(sql2.equals(null)){
                    System.out.println("Error in Customers");
                }if(sql3.equals(null)){
                    System.out.println("Error in Appointments");
                }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error: " + e);
        }
        return;
    }
}

