package DBUtilities;

/** @author Jonathan Fletcher */

import java.sql.*;

/**This class sets up the DB connection*/
public class DBConnection {
    //WGU DB information
    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String serverName = "//wgudb.ucertify.com:3306/";
    private static final String dbName = "WJ07TUk";
    private static final String jdbcURL = protocol + vendorName + serverName + dbName;
    private static final String MySQLjdbcDriver = "com.mysql.cj.jdbc.Driver";
    private static Connection connection = null;
    private static final String DBuserName = "U07TUk";
    private static final String DBpassword = "53689126047";



    /***
     * Method to establish connection with the DB.
     * @return DBconnection
     */
    public static Connection startConnection(){
        try {
            Class.forName(MySQLjdbcDriver);
            connection = DriverManager.getConnection(jdbcURL, DBuserName, DBpassword);
            System.out.println("Connection successful.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public static Connection getConnection(){
        return connection;
    }

    /***
     * Method to close the DB connection.
     */
    public static void closeConnection(){
        try {
            connection.close();
            System.out.println("Connection closed.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

}
