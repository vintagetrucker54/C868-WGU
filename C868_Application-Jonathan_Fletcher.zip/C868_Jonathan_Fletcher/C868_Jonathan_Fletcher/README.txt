                                        Scheduling Management Application C868
                                                                   
------------------------------------------------------------------------------------------------------------------------
                                     •  directions for how to run the program •
------------------------------------------------------------------------------------------------------------------------
Save the application to your computer and open in IntelliJ.
Click RUN -> Run 'Main'
Login with sample data, username = 'test' with password = 'test' or username = 'admin' with password = 'admin'
------------------------------------------------------------------------------------------------------------------------
                            •  author, contact information, application version, and date •
------------------------------------------------------------------------------------------------------------------------
Jonathan Fletcher jflet63@wgu.edu
App Ver1.01
IntelliJ IDEA 2021.1.1 (Community Edition)
Build #IC-211.7142.45, built on April 30, 2021
Runtime version: 11.0.10+9-b1341.41 amd64
VM: Dynamic Code Evolution 64-Bit Server VM by JetBrains s.r.o.
Windows 10 10.0
GC: ParNew, ConcurrentMarkSweep
Memory: 1486M
Cores: 4
Non-Bundled Plugins: com.markskelton.one-dark-theme (5.1.5), Dart (211.7233), org.toml.lang (0.2.146.3826-211), aws.toolkit (1.26-211), org.jetbrains.kotlin (211-1.5.0-release-759-IJ6693.72), io.flutter (56.0.5), org.intellij.scala (2021.1.20), org.rust.lang (0.3.146.3826-211)
Kotlin: 211-1.5.0-release-759-IJ6693.72
------------------------------------------------------------------------------------------------------------------------
